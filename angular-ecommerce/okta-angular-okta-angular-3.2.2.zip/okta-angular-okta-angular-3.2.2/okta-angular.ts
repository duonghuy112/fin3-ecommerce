// This file is not used to build the module. It is only used during editing
// by the TypeScript language service and during build for verification. `ngc`
// replaces this file with production okta-angular.ts when it rewrites
// private symbol names.

export * from './public-api';
