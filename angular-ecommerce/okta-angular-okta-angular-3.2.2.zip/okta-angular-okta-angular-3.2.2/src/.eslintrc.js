// https://eslint.org/docs/user-guide/configuring

module.exports = {
  extends: [
    'plugin:@typescript-eslint/recommended',
  ],
  plugins: [
    '@typescript-eslint'
  ]
};
