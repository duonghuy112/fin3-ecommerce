/**
 * Entry point for all public APIs of the package.
 */
export * from './src/okta-angular';

// This file only reexports content of the `src` folder. Keep it that way.
